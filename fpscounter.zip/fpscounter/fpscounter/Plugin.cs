﻿using BepInEx;
using UnityEngine;

[BepInPlugin("com.yourname.gtag.fpsdisplay", "FPS Display", "1.0.0")]
public class FPSDisplayMod : BaseUnityPlugin
{
    private float deltaTime = 0.0f;
    private GUIStyle fpsStyle;

    void Update()
    {
        deltaTime += (Time.unscaledDeltaTime - deltaTime) * 0.1f;
    }

    void OnGUI()
    {
        if (fpsStyle == null)
        {
            fpsStyle = new GUIStyle();
            fpsStyle.fontSize = 40;
            fpsStyle.normal.textColor = Color.white;
            fpsStyle.alignment = TextAnchor.UpperRight;
        }

        float fps = 1.0f / deltaTime;
        string fpsText = $"FPS: {Mathf.Ceil(fps)}";

        GUI.Label(new Rect(Screen.width - 220, 10, 200, 50), fpsText, fpsStyle);
    }
}
